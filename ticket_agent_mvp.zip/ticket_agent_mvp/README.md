# 自适应客户工单全流程处理 Agent MVP

## 功能
多 Agent 协作 + 长链推理的智能工单处理系统，支持：
- 意图分类
- 自动追问补全信息
- 根因分析（长链推理）
- 方案生成
- 闭环验证
- 信心不足/验证失败时自动转人工

## 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 运行（模拟模式，无需 API Key）
```bash
python main.py
```

### 3. 使用真实大模型
- 复制 `.env.example` 为 `.env`，填写你的 DeepSeek API Key，并设置 `USE_REAL_LLM=true`
- 或在环境变量中设置：
```bash
export DEEPSEEK_API_KEY="你的Key"
export USE_REAL_LLM=true
python main.py
```

## 架构说明
- **意图分类 Agent**：分流
- **追问 Agent**：信息补全
- **根因分析 Agent**：结合日志和知识库的长链推理
- **方案 Agent**：生成最小可行方案
- **验证 Agent**：模拟测试环境复现验证
- **主控制器**：协调各 Agent，根据置信度阈值决策是否转人工

## 自定义
可修改 `test_ticket` 字典中的内容测试不同工单场景。
