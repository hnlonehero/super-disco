import json
import os
from dataclasses import dataclass, field
from typing import Optional, List
from openai import OpenAI

# ========== 配置 ==========
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "your-api-key-here")
USE_REAL_LLM = os.getenv("USE_REAL_LLM", "false").lower() == "true"

if USE_REAL_LLM:
    client = OpenAI(
        api_key=DEEPSEEK_API_KEY,
        base_url="https://api.deepseek.com/v1",
    )
else:
    client = None  # 模拟模式不需要客户端

# ========== 数据结构 ==========
@dataclass
class TicketContext:
    ticket_id: str
    customer_query: str
    product_logs: Optional[str] = None
    knowledge_base: Optional[str] = None
    intent: str = ""
    follow_up_questions: List[str] = field(default_factory=list)
    customer_replies: dict = field(default_factory=dict)
    root_cause: str = ""
    root_cause_confidence: float = 0.0
    solution: str = ""
    solution_confidence: float = 0.0
    verification_result: str = ""
    final_resolution: str = ""
    trace: List[str] = field(default_factory=list)

# ========== Agent 基类 ==========
class BaseAgent:
    def __init__(self, name: str):
        self.name = name

    def call_llm(self, system_prompt: str, user_prompt: str, temperature=0.2) -> str:
        if not USE_REAL_LLM:
            return self._simulate_reply(system_prompt, user_prompt)
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content.strip()

    def _simulate_reply(self, system, user):
        raise NotImplementedError

    def run(self, ctx: TicketContext) -> TicketContext:
        raise NotImplementedError

# ========== 意图分类 Agent ==========
class IntentClassifierAgent(BaseAgent):
    def __init__(self):
        super().__init__("IntentClassifier")

    def _simulate_reply(self, system, user):
        if "无法登录" in user:
            return "登录问题"
        if "支付" in user:
            return "支付异常"
        if "卡顿" in user:
            return "性能问题"
        return "一般咨询"

    def run(self, ctx: TicketContext) -> TicketContext:
        prompt = f"客户问题：{ctx.customer_query}。请分类意图（登录问题/支付异常/性能问题/功能咨询/其他）。仅输出分类结果。"
        ctx.intent = self.call_llm("", prompt)
        ctx.trace.append(f"[{self.name}] 意图分类: {ctx.intent}")
        return ctx

# ========== 追问 Agent ==========
class FollowUpAgent(BaseAgent):
    def __init__(self):
        super().__init__("FollowUp")

    def _simulate_reply(self, system, user):
        return "1. 请问无法登录时页面提示什么错误？\n2. 您使用的是邮箱还是手机号登录？"

    def run(self, ctx: TicketContext) -> TicketContext:
        prompt = f"意图：{ctx.intent}。客户描述：{ctx.customer_query}。如需更多信息，生成最多3个追问，否则回复"无需追问"。"
        result = self.call_llm("", prompt)
        if "无需追问" in result:
            ctx.follow_up_questions = []
        else:
            lines = [line.strip() for line in result.split("\n") if line.strip() and line[0].isdigit()]
            ctx.follow_up_questions = lines
        ctx.trace.append(f"[{self.name}] 追问: {ctx.follow_up_questions}")
        return ctx

# ========== 根因分析 Agent ==========
class RootCauseAnalysisAgent(BaseAgent):
    def __init__(self, threshold=0.7):
        super().__init__("RootCauseAnalysis")
        self.threshold = threshold

    def _simulate_reply(self, system, user):
        return json.dumps({"root_cause": "认证服务配置错误导致登录失败", "confidence": 0.85})

    def run(self, ctx: TicketContext) -> TicketContext:
        extra = ""
        if ctx.follow_up_questions and ctx.customer_replies:
            qa = "\n".join([f"追问：{q}\n回答：{ctx.customer_replies.get(q, '')}" for q in ctx.follow_up_questions])
            extra = f"\n客户补充：\n{qa}"
        prompt = f"意图：{ctx.intent}\n原始描述：{ctx.customer_query}{extra}\n日志：{ctx.product_logs or '无'}\n知识库：{ctx.knowledge_base or '无'}\n输出JSON：{{\"root_cause\":\"...\", \"confidence\":0.0~1.0}}"
        result = self.call_llm("", prompt)
        try:
            data = json.loads(result)
            ctx.root_cause = data["root_cause"]
            ctx.root_cause_confidence = data["confidence"]
        except:
            ctx.root_cause = result
            ctx.root_cause_confidence = 0.5
        ctx.trace.append(f"[{self.name}] 根因: {ctx.root_cause} (信心:{ctx.root_cause_confidence})")
        return ctx

# ========== 方案生成 Agent ==========
class SolutionAgent(BaseAgent):
    def __init__(self, threshold=0.7):
        super().__init__("Solution")
        self.threshold = threshold

    def _simulate_reply(self, system, user):
        return json.dumps({"solution": "重置认证模块配置并重启服务", "confidence": 0.9})

    def run(self, ctx: TicketContext) -> TicketContext:
        prompt = f"根因：{ctx.root_cause}（信心{ctx.root_cause_confidence}）\n知识库：{ctx.knowledge_base or '无'}\n生成方案。输出JSON：{{\"solution\":\"...\", \"confidence\":0.0~1.0}}"
        result = self.call_llm("", prompt)
        try:
            data = json.loads(result)
            ctx.solution = data["solution"]
            ctx.solution_confidence = data["confidence"]
        except:
            ctx.solution = result
            ctx.solution_confidence = 0.5
        ctx.trace.append(f"[{self.name}] 方案: {ctx.solution} (信心:{ctx.solution_confidence})")
        return ctx

# ========== 验证 Agent ==========
class VerificationAgent(BaseAgent):
    def __init__(self):
        super().__init__("Verification")

    def _simulate_reply(self, system, user):
        return "测试环境验证通过：故障消除，登录功能恢复正常。"

    def run(self, ctx: TicketContext) -> TicketContext:
        prompt = f"根因：{ctx.root_cause}\n方案：{ctx.solution}\n请模拟验证该方案，输出结果（通过/失败及理由）。"
        ctx.verification_result = self.call_llm("", prompt)
        ctx.trace.append(f"[{self.name}] 验证结果: {ctx.verification_result}")
        return ctx

# ========== 主控制器 ==========
class TicketProcessor:
    def __init__(self, confidence_threshold=0.7):
        self.intent_agent = IntentClassifierAgent()
        self.followup_agent = FollowUpAgent()
        self.root_cause_agent = RootCauseAnalysisAgent(confidence_threshold)
        self.solution_agent = SolutionAgent(confidence_threshold)
        self.verification_agent = VerificationAgent()
        self.threshold = confidence_threshold

    def process(self, ticket_id, customer_query, product_logs=None, knowledge_base=None):
        ctx = TicketContext(
            ticket_id=ticket_id,
            customer_query=customer_query,
            product_logs=product_logs,
            knowledge_base=knowledge_base
        )
        print(f"\n===== 处理工单 {ticket_id} =====")
        ctx = self.intent_agent.run(ctx)
        ctx = self.followup_agent.run(ctx)
        if ctx.follow_up_questions:
            print(f"系统追问：{ctx.follow_up_questions}")
            ctx.customer_replies = {q: "模拟客户回答：错误码401，使用邮箱登录" for q in ctx.follow_up_questions}
            ctx.trace.append("[系统] 客户已补充信息")
        ctx = self.root_cause_agent.run(ctx)
        if ctx.root_cause_confidence < self.threshold:
            ctx.final_resolution = "转人工（根因置信度过低）"
            ctx.trace.append(f"[决策] 根因信心{ctx.root_cause_confidence}<{self.threshold}，转人工")
            print(ctx.final_resolution)
            return ctx
        ctx = self.solution_agent.run(ctx)
        if ctx.solution_confidence < self.threshold:
            ctx.final_resolution = "转人工（方案置信度过低）"
            ctx.trace.append(f"[决策] 方案信心{ctx.solution_confidence}<{self.threshold}，转人工")
            print(ctx.final_resolution)
            return ctx
        ctx = self.verification_agent.run(ctx)
        if "失败" in ctx.verification_result:
            ctx.final_resolution = f"验证失败，转人工。原因：{ctx.verification_result}"
            ctx.trace.append("[决策] 验证失败，转人工")
        else:
            ctx.final_resolution = f"自动闭环处理完成。方案：{ctx.solution}。验证：{ctx.verification_result}"
            ctx.trace.append("[系统] 工单自动闭环")
        print(f"最终结果: {ctx.final_resolution}")
        return ctx

# ========== 运行入口 ==========
if __name__ == "__main__":
    processor = TicketProcessor(confidence_threshold=0.7)
    
    # 模拟一个登录故障工单
    test_ticket = {
        "ticket_id": "T-20240501-001",
        "customer_query": "从今天早上开始我就无法登录系统，页面转圈后显示错误，已经尝试清除缓存",
        "product_logs": "2024-05-01 08:30:22 认证服务 auth-svc 出现大量 5xx 错误，/login 接口超时",
        "knowledge_base": "常见登录失败：1) 认证服务配置错误；2) 数据库连接池耗尽；3) SSO证书过期。"
    }
    
    ctx = processor.process(**test_ticket)
    
    print("\n===== 完整推理链 =====")
    for step in ctx.trace:
        print(step)
